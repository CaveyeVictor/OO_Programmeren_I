// Fig 2.4: Welcome4.java
// Displaying multiple lines with method System.out.printf

public class Welcome4 {
      // main method begins execution of Java application
    public static void main(String[] args)
    {
        System.out.printf("%s%n%s%n","Welcome to","Java Programming!");
    }// end method main
}// end class Welcome4
