
import java.util.Scanner;

public class Comparison
{
    // main method start de uitvoering van Java applicatie

    public static void main(String[] args)
    {
        // creëer een object van Scanner; voor invoer vanaf het toetsenbord
        Scanner input = new Scanner(System.in);

        int number1;          // eerste getal om te vergelijken
        int number2;          // tweede getal om te vergelijken

        System.out.print("Enter first integer: "); // prompt
        number1 = input.nextInt(); // leest eerste getal van de gebruiker

        System.out.print("Enter second integer: "); // prompt 
        number2 = input.nextInt(); // leest tweede getal van de gebruiker

        if (number1 == number2)
        {
            System.out.printf("%d == %d\n", number1, number2);
        }

        if (number1 != number2)
        {
            System.out.printf("%d != %d\n", number1, number2);
        }

        if (number1 < number2)
        {
            System.out.printf("%d < %d\n", number1, number2);
        }

        if (number1 > number2)
        {
            System.out.printf("%d > %d\n", number1, number2);
        }

        if (number1 <= number2)
        {
            System.out.printf("%d <= %d\n", number1, number2);
        }

        if (number1 >= number2)
        {
            System.out.printf("%d >= %d\n", number1, number2);
        }

    } // methode main
}
