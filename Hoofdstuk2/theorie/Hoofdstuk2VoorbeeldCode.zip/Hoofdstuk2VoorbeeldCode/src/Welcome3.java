// Fig 2.4: Welcome3.java
// Printing multiple lines of text with a single statement

public class Welcome3 {
      // main method begins execution of Java application
    public static void main(String[] args)
    {
        System.out.println("Welcome\nto\nJava\nProgramming!");
    }// end method main
}// end class Welcome3
